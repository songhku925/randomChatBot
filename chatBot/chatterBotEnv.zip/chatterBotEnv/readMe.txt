Please move data inside data folder to user home folder and extract them before running chatter bot
You may beed to change some python code to override downloading nltk and ubuntu_dialogs data